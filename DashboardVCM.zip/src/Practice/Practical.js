import React from "react";



function Practical() {
  return (
    <>
      <h1>hellos</h1>
    </>
  );
}

export default Practical;
